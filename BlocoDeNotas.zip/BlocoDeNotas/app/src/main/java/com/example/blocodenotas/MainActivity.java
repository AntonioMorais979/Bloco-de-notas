package com.example.blocodenotas;

import android.annotation.SuppressLint;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.style.UnderlineSpan;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private
    EditText editText;
    private RadioButton rbNegrito, rbItalico, rbSublinhado;
    private Button btnSalvar;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        editText = findViewById(R.id.editTextTextMultiLine);
        rbNegrito = findViewById(R.id.rbNegrito);
        rbItalico = findViewById(R.id.rbItalico);
        rbSublinhado = findViewById(R.id.rbSublinhado);
        btnSalvar = findViewById(R.id.btnSalvar);

        RadioGroup radioGroup = findViewById(R.id.radioGroup);
        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            switch (checkedId) {
                case R.id.rbNegrito:

                    editText.setTypeface(null, Typeface.BOLD);
                    break;
                case R.id.rbItalico:
                    editText.setTypeface(null, Typeface.ITALIC);
                    break;
                case R.id.rbSublinhado:
                    editText.setSpannableFactory(new UnderlineSpan(), 0, editText.getText().length(), 0);
                    break;
            }
        });

        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Implementar a lógica de salvar aqui
                // Por exemplo, salvar em um arquivo, banco de dados, etc.
                String textoFormatado = editText.getText().toString();
                // ...
            }
        });
    }
}